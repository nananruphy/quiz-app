package com.example.sciencequizerprimary;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sciencequizerprimary6.R;

public class MainActivity extends AppCompatActivity {

    int correctAnswers;
    int total_score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * methods to get correct answers from user.
     */
    public void submitAnswers(View view) {
        //Question 1
        RadioGroup radioGroup_q1 = findViewById(R.id.q1_RadioGroup);
        if (radioGroup_q1.getCheckedRadioButtonId() == R.id.answerC_radiobutton) {
            correctAnswers = correctAnswers + 1;
        }
        //Question 2
        CheckBox answerA = findViewById(R.id.answerA_checkbox);
        CheckBox answerB = findViewById(R.id.answerB_checkbox);
        CheckBox answerC = findViewById(R.id.answerC_checkbox);
        CheckBox answerD = findViewById(R.id.answerD_checkbox);
        if (answerA.isChecked() && answerC.isChecked() && answerD.isChecked() && !answerB.isChecked()) {
            correctAnswers = correctAnswers + 1;
        }
        //@Question 3
        EditText answer3 = findViewById(R.id.answer3_edittext);
        String input_answer = answer3.getText().toString().trim();
        if (input_answer.equalsIgnoreCase("roots")) {
            correctAnswers = correctAnswers + 1;
        }
        //@Question 4
        RadioGroup radioGroup_q4 = findViewById(R.id.q4_RadioGroup);
        if (radioGroup_q4.getCheckedRadioButtonId() == R.id.answercycleB_radiobutton) {
            correctAnswers = correctAnswers + 1;
        }
        if (radioGroup_q1.getCheckedRadioButtonId() == -1
                || !answerA.isChecked() && !answerB.isChecked() && !answerC.isChecked() && !answerD.isChecked()
                || answer3.getText().toString().isEmpty()
                || radioGroup_q4.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "Incomplete Quiz! Please answer all questions", Toast.LENGTH_SHORT).show();
        } else {
            /*
             * calculate the Total score in percentage
             */
            total_score = correctAnswers;
        }
        TextView final_score = findViewById(R.id.quizScore_textview);
        //Toast.makeText(this, "Your total score is: " + total_score + " out of 4", Toast.LENGTH_SHORT).show();
        final_score.setText("Your total score is: " + total_score + " out of 4");
        //Deactivate submit button
        Button btn = findViewById(R.id.submit_button);
        btn.setEnabled(false);
    }

    //Reset method to clear wrong selection of user and active submit button
    public void resetAnswers(View view) {
        RadioGroup reset_q1 = findViewById(R.id.q1_RadioGroup);
        reset_q1.clearCheck();
        RadioGroup reset_q4 = findViewById(R.id.q4_RadioGroup);
        reset_q4.clearCheck();
        CheckBox cb_A = findViewById(R.id.answerA_checkbox);
        cb_A.setChecked(false);
        CheckBox cb_B = findViewById(R.id.answerB_checkbox);
        cb_B.setChecked(false);
        CheckBox cb_C = findViewById(R.id.answerC_checkbox);
        cb_C.setChecked(false);
        CheckBox cb_D = findViewById(R.id.answerD_checkbox);
        cb_D.setChecked(false);
        EditText answer3 = findViewById(R.id.answer3_edittext);
        answer3.setText("");
        TextView resetScore = findViewById(R.id.quizScore_textview);
        resetScore.setText("Your total score is: " + 0 + " out of 4");
        Button btn = findViewById(R.id.submit_button);
        btn.setEnabled(true);
    }
}