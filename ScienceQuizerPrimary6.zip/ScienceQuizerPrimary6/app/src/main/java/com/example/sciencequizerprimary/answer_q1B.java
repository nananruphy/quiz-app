package com.example.sciencequizerprimary;

public class answer_q1B {
}
